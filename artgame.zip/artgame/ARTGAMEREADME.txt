Robert Roche
Art Game


I began this game as a forge level in Halo reach. This became too abstract as I could place any prompts, and the halo mechanics did not lend
itself to my vision. I changed to a very low interactive game. I wanted to convery how many (not all) triple a games often feel like they have less
meaningful content than indie games. After playtesting I found my players did not find my game to be game-y enough. I scrapped this idea
and moved on to make a game that is a metaphor for the pressurized crunch culture we see in the triple a industry, as opposed to indie devs
who often work in more low pressue environemnts who often work in small cozy studios or from home. I did not use another game as my raw material
however my general format can be implemented into almost any game. The game I made makes you pickup burgers. In the AAA area, you are on a
time crunch and in a factory, in the indie environment you're in a cozy cabin with no time limit.
